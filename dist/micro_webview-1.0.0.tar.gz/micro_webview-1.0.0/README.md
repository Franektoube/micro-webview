Minimal Web View based on PyQtWebEngine

Just use WebView function

It's all

NOTE: use import microwebview instead import micro-webview. import microweb-view isn't working.
